<?php
class Post extends AppModel {
    public $name = 'Post';
	
    public $validate = array(
        'titulo' => array(
            'rule' => 'notBlank',
			'message'=>'Este campo não pode ser vazio'
        ),
        'corpo' => array(
            'rule' => 'notBlank',
			'message'=>'Este campo não pode ser vazio' 
        ),
		
		'tag' => array(
            'rule' => 'notBlank',
			'message'=>'Este campo não pode ser vazio' 
        ),
		
				'autor' => array(
            'rule' => 'notBlank',
			'message'=>'Este campo não pode ser vazio' 
        )
		
    );	
}?>